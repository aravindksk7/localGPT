# Acknowledgments

Some code was taken or inspired from other projects:-

- [CookieCutter Django][cookiecutter-django]
  - `pre-commit-config.yaml` is taken from there with almost no changes
  - `github-actions.yml` is inspired by `gitlab-ci.yml`
  - `.pyup.yml`, `.flake8`, `.editorconfig`, `pyproject.toml` are taken from there with minor changes,

[cookiecutter-django]: https://github.com/cookiecutter/cookiecutter-django
